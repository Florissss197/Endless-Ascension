using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace EndlessAscension
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LauncherForm());
        }
    }

    internal sealed class LauncherForm : Form
    {
        private readonly string root = AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);
        private readonly TextBox gamePath = new TextBox();
        private readonly TextBox log = new TextBox();
        private readonly Label status = new Label();
        private readonly CheckBox acknowledge = new CheckBox();
        private readonly Button installLaunch = new Button();
        private const string GameExe = "Binaries\\Win32\\SanctumGame-Win32-Shipping.exe";
        private const string RunUrl = "RockyFields_04?game=SanctumGame.SGGameSandbox?EnemyHPScale=100?TowerResourceScale=100?WallResourceScale=100?WeaponSlots=4?listen";

        public LauncherForm()
        {
            Text = "Endless Ascension | Preview Launcher";
            MinimumSize = new Size(760, 600);
            Size = new Size(850, 680);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(7, 18, 27);
            ForeColor = Color.FromArgb(230, 243, 248);
            Font = new Font("Segoe UI", 10F);

            var title = new Label { Text = "ENDLESS ASCENSION", Location = new Point(28, 24), AutoSize = true, Font = new Font("Segoe UI Semibold", 23F), ForeColor = Color.FromArgb(66, 214, 255) };
            Controls.Add(title);
            Controls.Add(new Label { Text = "DEV 0.2CI · Challenge preview · UltimateWeener", Location = new Point(32, 68), AutoSize = true, ForeColor = Color.FromArgb(170, 193, 205) });

            var panel = new Panel { Location = new Point(26, 112), Size = new Size(780, 150), BackColor = Color.FromArgb(16, 36, 51) };
            Controls.Add(panel);
            panel.Controls.Add(new Label { Text = "Sanctum 2 installation folder", Location = new Point(18, 18), AutoSize = true, ForeColor = Color.White });
            gamePath.Location = new Point(20, 50); gamePath.Size = new Size(610, 29); gamePath.BackColor = Color.FromArgb(5, 17, 27); gamePath.ForeColor = Color.White; gamePath.BorderStyle = BorderStyle.FixedSingle;
            panel.Controls.Add(gamePath);
            var browse = MakeButton("BROWSE", 642, 48, 112, 33, false); browse.Click += (s, e) => BrowseGame(); panel.Controls.Add(browse);
            panel.Controls.Add(new Label { Text = "Select the folder containing Binaries and SanctumGame. The game must be closed for install/uninstall.", Location = new Point(20, 91), Size = new Size(730, 42), ForeColor = Color.FromArgb(170, 193, 205) });

            var buildInfo = new Label { Text = "Included profile: fixed Challenge preview (x1 enemy count, x1 resilience). Custom Sandbox and tuning are not in this package.", Location = new Point(30, 280), Size = new Size(770, 42), ForeColor = Color.FromArgb(255, 198, 111) };
            Controls.Add(buildInfo);
            acknowledge.Text = "I understand this is a development preview; in-game stability and LAN play are not verified.";
            acknowledge.Location = new Point(30, 326); acknowledge.Size = new Size(760, 28); acknowledge.ForeColor = Color.FromArgb(220, 232, 238);
            acknowledge.CheckedChanged += (s, e) => installLaunch.Enabled = acknowledge.Checked;
            Controls.Add(acknowledge);

            installLaunch = MakeButton("INSTALL & LAUNCH", 30, 374, 230, 48, true);
            installLaunch.Enabled = false;
            installLaunch.Click += (s, e) => InstallAndLaunch();
            Controls.Add(installLaunch);
            var launch = MakeButton("LAUNCH INSTALLED", 274, 374, 210, 48, false); launch.Click += (s, e) => LaunchInstalled(); Controls.Add(launch);
            var uninstall = MakeButton("UNINSTALL", 498, 374, 150, 48, false); uninstall.Click += (s, e) => Uninstall(); Controls.Add(uninstall);

            status.Text = "Choose your Sanctum 2 folder. The launcher will verify the game version before installing.";
            status.Location = new Point(31, 434); status.Size = new Size(775, 28); status.ForeColor = Color.FromArgb(66, 214, 255); Controls.Add(status);
            log.Location = new Point(30, 472); log.Size = new Size(776, 145); log.Multiline = true; log.ReadOnly = true; log.ScrollBars = ScrollBars.Vertical; log.BackColor = Color.FromArgb(4, 13, 21); log.ForeColor = Color.FromArgb(195, 226, 238); log.Font = new Font("Consolas", 9F); Controls.Add(log);

            LoadSavedPath();
            if (!File.Exists(Path.Combine(root, "release.json")) || !File.Exists(Path.Combine(root, "Install.ps1")))
            {
                status.Text = "Package files are incomplete. Extract the entire preview ZIP, then start this EXE again.";
                installLaunch.Enabled = false;
            }
            Append("Ready. This launcher installs only the included preview package and can restore its backup.");
        }

        private Button MakeButton(string text, int x, int y, int w, int h, bool accent)
        {
            return new Button { Text = text, Location = new Point(x, y), Size = new Size(w, h), FlatStyle = FlatStyle.Flat, BackColor = accent ? Color.FromArgb(18, 177, 218) : Color.FromArgb(17, 40, 56), ForeColor = Color.White, Font = new Font("Segoe UI Semibold", 9.5F), Cursor = Cursors.Hand };
        }

        private void BrowseGame()
        {
            using (var dialog = new FolderBrowserDialog())
            {
                dialog.Description = "Choose the Sanctum 2 install folder (the folder containing Binaries).";
                if (Directory.Exists(gamePath.Text)) dialog.SelectedPath = gamePath.Text;
                if (dialog.ShowDialog(this) == DialogResult.OK) { gamePath.Text = dialog.SelectedPath; SavePath(); }
            }
        }

        private void LoadSavedPath()
        {
            var file = Path.Combine(root, "launcher-settings.local.txt");
            if (File.Exists(file)) gamePath.Text = File.ReadAllText(file).Trim();
            if (IsValidGameRoot(gamePath.Text)) return;
            var common = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Steam", "steamapps", "common", "Sanctum 2");
            if (IsValidGameRoot(common)) gamePath.Text = common;
        }

        private void SavePath()
        {
            try { File.WriteAllText(Path.Combine(root, "launcher-settings.local.txt"), gamePath.Text.Trim()); }
            catch (Exception ex) { Append("Could not save selected path: " + ex.Message); }
        }

        private bool IsValidGameRoot(string path) { return !String.IsNullOrWhiteSpace(path) && File.Exists(Path.Combine(path, GameExe)) && File.Exists(Path.Combine(path, "SanctumGame\\CookedPC\\SanctumGame.u")); }

        private string SelectedGameRoot()
        {
            var path = gamePath.Text.Trim().Trim('"');
            if (!IsValidGameRoot(path)) throw new InvalidOperationException("Select the Sanctum 2 folder containing Binaries and SanctumGame.");
            SavePath();
            return Path.GetFullPath(path);
        }

        private bool RunPowerShell(string script, string gameRoot)
        {
            var scriptPath = Path.Combine(root, script);
            if (!File.Exists(scriptPath)) throw new FileNotFoundException("Missing package script", scriptPath);
            var psi = new ProcessStartInfo { FileName = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell\\v1.0\\powershell.exe"), WorkingDirectory = root, UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true, Arguments = "-NoLogo -NoProfile -ExecutionPolicy Bypass -File \"" + scriptPath + "\" -GamePath \"" + gameRoot.Replace("\"", "") + "\"" };
            using (var p = Process.Start(psi))
            {
                var output = p.StandardOutput.ReadToEnd(); var error = p.StandardError.ReadToEnd(); p.WaitForExit();
                if (!String.IsNullOrWhiteSpace(output)) Append(output.Trim());
                if (!String.IsNullOrWhiteSpace(error)) Append(error.Trim());
                return p.ExitCode == 0;
            }
        }

        private void InstallAndLaunch()
        {
            try
            {
                var game = SelectedGameRoot();
                if (Process.GetProcessesByName("SanctumGame-Win32-Shipping").Length > 0) throw new InvalidOperationException("Close Sanctum 2 before installing the preview.");
                status.Text = "Checking the installed game and applying the preview backup-safely..."; Refresh();
                bool installed = RunPowerShell("Check.ps1", game);
                if (!installed && !RunPowerShell("Install.ps1", game)) throw new InvalidOperationException("Install failed. See the diagnostics below; no launch attempted.");
                status.Text = "Mod files verified. Starting Sanctum 2..."; Refresh();
                StartGame(game);
                status.Text = "Sanctum 2 launched with the included Challenge preview profile.";
            }
            catch (Exception ex) { status.Text = "Could not start the preview."; Append("ERROR: " + ex.Message); MessageBox.Show(this, ex.Message + "\n\nSee the diagnostics panel for details.", "Endless Ascension", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void LaunchInstalled()
        {
            try
            {
                var game = SelectedGameRoot();
                if (!RunPowerShell("Check.ps1", game)) throw new InvalidOperationException("The preview is not installed or its files failed verification. Use INSTALL & LAUNCH first.");
                StartGame(game); status.Text = "Sanctum 2 launched with the included Challenge preview profile.";
            }
            catch (Exception ex) { Append("ERROR: " + ex.Message); MessageBox.Show(this, ex.Message, "Endless Ascension", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void StartGame(string game)
        {
            var exe = Path.Combine(game, GameExe);
            var psi = new ProcessStartInfo { FileName = exe, WorkingDirectory = Path.GetDirectoryName(exe), UseShellExecute = false, Arguments = RunUrl + " -nohomedir -log -windowed -ResX=1920 -ResY=1080" };
            psi.EnvironmentVariables["SteamAppId"] = "210770"; psi.EnvironmentVariables["SteamGameId"] = "210770";
            Process.Start(psi);
            Append("GAME_START " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " profile=Challenge preview GPU=automatic");
        }

        private void Uninstall()
        {
            try
            {
                var game = SelectedGameRoot();
                if (Process.GetProcessesByName("SanctumGame-Win32-Shipping").Length > 0) throw new InvalidOperationException("Close Sanctum 2 before uninstalling.");
                if (MessageBox.Show(this, "Restore the original SanctumGame.u backup for this installation?", "Confirm uninstall", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
                if (!RunPowerShell("Uninstall.ps1", game)) throw new InvalidOperationException("Uninstall failed. See the diagnostics below.");
                status.Text = "Original game file restored and verified.";
            }
            catch (Exception ex) { Append("ERROR: " + ex.Message); MessageBox.Show(this, ex.Message, "Endless Ascension", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void Append(string text) { if (log.IsDisposed) return; log.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] " + text + Environment.NewLine); }
    }
}
