# Endless Ascension

A community-made Sanctum 2 mod project by UltimateWeener.

## Current status

The repository contains installer source, the Windows launcher source, and a project preview page. No game files or personal machine paths belong in this source repository.

The current development preview has one fixed Challenge profile (x1 enemy count, x1 resilience). Runtime gameplay and LAN co-op are not verified. It does not contain the configurable Sandbox mode or the in-game shop.

## GitHub layout

- Upload the contents of this folder to a **private** repository.
- Build `EndlessAscensionLauncher.exe` with `Build-Launcher.cmd` on Windows.
- Keep the game-specific Dev Preview ZIP as a private GitHub Release asset. It contains a binary patch derived from Sanctum 2 and should not be published in a public repository.
- Each player needs their own Sanctum 2 installation. The preview launcher has Install & Launch and Uninstall buttons and restores the original package from backup.

## Files

- `EndlessAscension-installer/` — reversible installer toolkit, checker, uninstaller, and release builder.
- `EndlessAscensionLauncher.cs` — source for the Windows launcher included in the preview ZIP.
- `Project-Preview.html` — friend-facing project overview and roadmap.

Do not describe the current preview as stable until it has passed a full game run and a two-PC co-op test.
