@echo off
setlocal
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
  echo .NET Framework C# compiler not found. Install the .NET Framework Developer Pack to build from source.
  pause
  exit /b 1
)
"%CSC%" /nologo /target:winexe /out:"%~dp0EndlessAscensionLauncher.exe" /r:System.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll "%~dp0EndlessAscensionLauncher.cs"
if errorlevel 1 pause
if not errorlevel 1 echo Built EndlessAscensionLauncher.exe
