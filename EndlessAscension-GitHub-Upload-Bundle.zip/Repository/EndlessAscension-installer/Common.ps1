Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$script:Product = 'EndlessAscension'
$script:StateFolder = '.endless-ascension'

function Get-Sha([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Assert-PlainPath([string]$Path) {
    $itemPath = [IO.Path]::GetFullPath($Path)
    while ($itemPath) {
        if (Test-Path -LiteralPath $itemPath) {
            $item = Get-Item -LiteralPath $itemPath -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "Symbolic links/junctions are not supported: $itemPath"
            }
        }
        $parent = [IO.Directory]::GetParent($itemPath)
        if ($null -eq $parent) { break }
        $itemPath = $parent.FullName
    }
}

function Get-SafePath([string]$Root, [string]$Relative) {
    if ([string]::IsNullOrWhiteSpace($Relative) -or $Relative -match '(^[\\/]|:|[\x00-\x1f])') {
        throw "Invalid relative path: $Relative"
    }
    $parts = $Relative -split '[\\/]'
    foreach ($part in $parts) {
        if ($part -eq '' -or $part -eq '.' -or $part -eq '..' -or $part -match '[ .]$|[<>"|?*]' -or
            $part -match '^(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)') { throw "Unsafe path: $Relative" }
    }
    $base = [IO.Path]::GetFullPath($Root).TrimEnd('\','/') + [IO.Path]::DirectorySeparatorChar
    $full = [IO.Path]::GetFullPath((Join-Path $base ($parts -join [IO.Path]::DirectorySeparatorChar)))
    if (-not $full.StartsWith($base, [StringComparison]::OrdinalIgnoreCase)) { throw "Path outside root: $Relative" }
    Assert-PlainPath $full
    return $full
}

function Assert-GameFile([string]$Relative) {
    $normalized = $Relative.Replace('\','/')
    if ($normalized -notmatch '^SanctumGame/(Config/[^/]+\.ini|CookedPC/.+\.(u|upk|sanctum))$') {
        throw "Unsupported game destination: $Relative"
    }
}

function Write-Json([string]$Path, $Value) {
    $temporary = $Path + '.tmp'
    Assert-PlainPath $Path
    Assert-PlainPath $temporary
    $json = $Value | ConvertTo-Json -Depth 12
    [IO.File]::WriteAllText($temporary, $json, (New-Object Text.UTF8Encoding($false)))
    Move-Item -LiteralPath $temporary -Destination $Path -Force
}

function Resolve-GameRoot([string]$GamePath) {
    if ($GamePath) {
        $root = [IO.Path]::GetFullPath($GamePath).TrimEnd('\','/')
        Assert-PlainPath $root
        foreach ($relative in @('Binaries/Win32/SanctumGame-Win32-Shipping.exe')) {
            if (-not (Test-Path -LiteralPath (Get-SafePath $root $relative) -PathType Leaf)) {
                throw "Not a Sanctum 2 installation: $root (missing $relative)"
            }
        }
        return $root
    }
    $steamRoots = @()
    foreach ($key in @('HKCU:\Software\Valve\Steam','HKLM:\SOFTWARE\WOW6432Node\Valve\Steam')) {
        if (Test-Path $key) {
            $settings = Get-ItemProperty $key
            foreach ($name in @('SteamPath','InstallPath')) {
                if ($settings.PSObject.Properties[$name]) { $steamRoots += [string]$settings.$name }
            }
        }
    }
    if (${env:ProgramFiles(x86)}) { $steamRoots += Join-Path ${env:ProgramFiles(x86)} 'Steam' }
    $libraries = @($steamRoots)
    foreach ($steam in ($steamRoots | Select-Object -Unique)) {
        $vdf = Join-Path $steam 'steamapps/libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf -PathType Leaf) {
            foreach ($match in [regex]::Matches([IO.File]::ReadAllText($vdf), '"path"\s*"([^"]+)"')) {
                $libraries += $match.Groups[1].Value.Replace('\\','\')
            }
        }
    }
    $found = @()
    foreach ($library in ($libraries | Select-Object -Unique)) {
        $manifest = Join-Path $library 'steamapps/appmanifest_210770.acf'
        if (Test-Path -LiteralPath $manifest -PathType Leaf) {
            $match = [regex]::Match([IO.File]::ReadAllText($manifest), '"installdir"\s*"([^"]+)"')
            if ($match.Success) {
                $candidate = Get-SafePath (Join-Path $library 'steamapps/common') $match.Groups[1].Value
                if (Test-Path -LiteralPath (Join-Path $candidate 'Binaries/Win32/SanctumGame-Win32-Shipping.exe')) { $found += $candidate }
            }
        }
    }
    $found = @($found | Select-Object -Unique)
    if ($found.Count -eq 1) { return Resolve-GameRoot $found[0] }
    throw 'Could not uniquely locate Sanctum 2. Run the script with -GamePath "D:\SteamLibrary\steamapps\common\Sanctum2".'
}

function Assert-GameClosed {
    if (Get-Process -Name 'SanctumGame-Win32-Shipping' -ErrorAction SilentlyContinue) {
        throw 'Close Sanctum 2 before installing or uninstalling.'
    }
}

function Enter-InstallLock([string]$Root) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $key = [BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Root.ToLowerInvariant()))).Replace('-','') }
    finally { $sha.Dispose() }
    $mutex = New-Object Threading.Mutex($false, ('Local\EndlessAscension-' + $key))
    try { $acquired = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $acquired = $true }
    if (-not $acquired) { $mutex.Dispose(); throw 'Another installer/check/uninstaller is using this game folder.' }
    return $mutex
}

function Assert-Hash([string]$Value) {
    if ($Value -notmatch '^[a-f0-9]{64}$') { throw 'Invalid SHA-256 in manifest.' }
}

function Read-Release([string]$Bundle) {
    $path = Get-SafePath $Bundle 'release.json'
    $release = [IO.File]::ReadAllText($path) | ConvertFrom-Json
    if ($release.schema -ne 1 -or $release.product -ne $script:Product) { throw 'Unknown release format.' }
    if ($release.ready -ne $true) {
        throw 'This is the installer toolkit, NOT a playable mod release. Compiled/tested mod files have not been supplied. No game files were changed.'
    }
    if ($release.version -notmatch '^[0-9]+\.[0-9]+\.[0-9]+(?:-[a-zA-Z0-9.-]+)?$') { throw 'Invalid release version.' }
    if (@($release.files).Count -eq 0 -or @($release.requiredBase).Count -lt 3) { throw 'Empty or incomplete release.' }
    $seen = @{}
    foreach ($file in $release.files) {
        Assert-GameFile $file.path
        $null = Get-SafePath $Bundle $file.path
        $key = $file.path.Replace('\','/').ToLowerInvariant()
        if ($seen.ContainsKey($key)) { throw "Duplicate destination: $key" }
        $seen[$key] = $true
        if ($file.mode -notin @('patch','add')) { throw 'Unsupported installation operation.' }
        Assert-Hash $file.installedSha256
        Assert-Hash $file.payloadSha256
        if ($file.mode -eq 'patch') { Assert-Hash $file.originalSha256 }
        $payload = Get-SafePath $Bundle $file.payload
        if ((Get-Sha $payload) -ne $file.payloadSha256) { throw "Damaged payload: $($file.payload)" }
    }
    $baseSeen = @{}
    foreach ($baseFile in $release.requiredBase) {
        $null = Get-SafePath $Bundle $baseFile.path
        Assert-Hash $baseFile.sha256
        $key = $baseFile.path.Replace('\','/').ToLowerInvariant()
        if ($baseSeen.ContainsKey($key)) { throw 'Duplicate base requirement.' }
        $baseSeen[$key] = $true
    }
    foreach ($required in @('binaries/win32/sanctumgame-win32-shipping.exe','sanctumgame/cookedpc/sanctumgame.u','sanctumgame/cookedpc/levels/playable/rockyfields_04.sanctum')) {
        if (-not $baseSeen.ContainsKey($required)) { throw "Missing base requirement: $required" }
    }
    return $release
}

function Apply-Delta([string]$Original, [string]$Delta, [string]$Destination) {
    $reader = New-Object IO.BinaryReader([IO.File]::OpenRead($Delta))
    $output = $null
    try {
        if ([Text.Encoding]::ASCII.GetString($reader.ReadBytes(8)) -ne 'EAPATCH1') { throw 'Invalid patch header.' }
        $length = $reader.ReadInt64()
        $count = $reader.ReadInt32()
        if ($length -lt 0 -or $length -gt 536870912 -or $count -lt 0 -or $count -gt 131072) { throw 'Invalid patch size.' }
        Copy-Item -LiteralPath $Original -Destination $Destination
        $output = [IO.File]::Open($Destination, [IO.FileMode]::Open, [IO.FileAccess]::Write, [IO.FileShare]::None)
        $output.SetLength($length)
        [long]$lastEnd = 0
        for ($i = 0; $i -lt $count; $i++) {
            $offset = $reader.ReadInt64()
            $size = $reader.ReadInt32()
            if ($offset -lt $lastEnd -or $size -le 0 -or $size -gt 4096 -or $offset -gt ($length - $size)) { throw 'Invalid patch block.' }
            $bytes = $reader.ReadBytes($size)
            if ($bytes.Length -ne $size) { throw 'Truncated patch.' }
            $output.Position = $offset
            $output.Write($bytes, 0, $bytes.Length)
            $lastEnd = $offset + $size
        }
        if ($reader.BaseStream.Position -ne $reader.BaseStream.Length) { throw 'Unexpected trailing patch data.' }
    } finally {
        if ($null -ne $output) { $output.Dispose() }
        $reader.Dispose()
    }
}

function Read-State([string]$Root) {
    $statePath = Get-SafePath $Root ($script:StateFolder + '/state.json')
    if (-not (Test-Path -LiteralPath $statePath)) { return $null }
    $state = [IO.File]::ReadAllText($statePath) | ConvertFrom-Json
    if ($state.schema -ne 1 -or $state.product -ne $script:Product -or $state.root -ne $Root) { throw 'Invalid installation journal.' }
    if ($state.phase -notin @('preparing','installing','installed','removing')) { throw 'Invalid installation phase.' }
    Assert-Hash $state.releaseId
    $seen = @{}
    $index = 0
    foreach ($entry in $state.files) {
        Assert-GameFile $entry.path
        $key = (Get-SafePath $Root $entry.path).ToLowerInvariant()
        if ($seen.ContainsKey($key)) { throw 'Duplicate journal path.' }
        $seen[$key] = $true
        if ($entry.mode -notin @('patch','add')) { throw 'Invalid journal operation.' }
        Assert-Hash $entry.installedSha256
        if ($entry.mode -eq 'patch') { Assert-Hash $entry.originalSha256 }
        if ($entry.backup -ne ('backup/{0:D4}.bin' -f $index)) { throw 'Invalid backup location.' }
        $index++
    }
    return $state
}

function Remove-Installation([string]$Root) {
    $state = Read-State $Root
    if ($null -eq $state) { Write-Host 'Endless Ascension is not installed.'; return }
    $stateRoot = Get-SafePath $Root $script:StateFolder
    # Preflight every file BEFORE changing any file. Preserve later user/game edits.
    foreach ($entry in $state.files) {
        if (-not $entry.attempted) { continue }
        $target = Get-SafePath $Root $entry.path
        if (Test-Path -LiteralPath $target) {
            $hash = Get-Sha $target
            if ($hash -ne $entry.installedSha256 -and ($entry.mode -ne 'patch' -or $hash -ne $entry.originalSha256)) {
                throw "File changed since installation: $($entry.path). Preserve this file elsewhere, then remove it and rerun Uninstall. The original backup is retained."
            }
        }
        if ($entry.mode -eq 'patch') {
            $backup = Get-SafePath $stateRoot $entry.backup
            if ((Get-Sha $backup) -ne $entry.originalSha256) { throw "Backup is missing or damaged: $($entry.path). Restore from your own backup or Steam; automatic uninstall stopped." }
        }
    }
    $state.phase = 'removing'
    Write-Json (Join-Path $stateRoot 'state.json') $state
    foreach ($entry in $state.files) {
        if (-not $entry.attempted) { continue }
        $target = Get-SafePath $Root $entry.path
        if ($entry.mode -eq 'patch') {
            Copy-Item -LiteralPath (Get-SafePath $stateRoot $entry.backup) -Destination $target -Force
            if ((Get-Sha $target) -ne $entry.originalSha256) { throw "Restore verification failed: $($entry.path)" }
        } elseif (Test-Path -LiteralPath $target) {
            Remove-Item -LiteralPath $target
        }
    }
    # Delete only files owned by this installer. Unknown files keep the folder alive.
    foreach ($directory in @('stage','backup')) {
        foreach ($entry in $state.files) {
            $name = [IO.Path]::GetFileName($entry.backup)
            $owned = Get-SafePath $stateRoot ($directory + '/' + $name)
            if (Test-Path -LiteralPath $owned -PathType Leaf) { Remove-Item -LiteralPath $owned }
        }
        $folder = Get-SafePath $stateRoot $directory
        if ((Test-Path -LiteralPath $folder -PathType Container) -and @(Get-ChildItem -LiteralPath $folder -Force).Count -eq 0) { [IO.Directory]::Delete($folder) }
    }
    Remove-Item -LiteralPath (Join-Path $stateRoot 'state.json')
    if (@(Get-ChildItem -LiteralPath $stateRoot -Force).Count -eq 0) { [IO.Directory]::Delete($stateRoot) }
    Write-Host 'Uninstalled. Original file contents restored and verified.'
}

function Install-Release([string]$Bundle, [string]$Root) {
    $release = Read-Release $Bundle
    $stateRoot = Get-SafePath $Root $script:StateFolder
    if (Test-Path -LiteralPath $stateRoot) { throw 'An installation or recovery folder already exists. Run Uninstall first; do not delete backups.' }
    foreach ($baseFile in $release.requiredBase) {
        if ((Get-Sha (Get-SafePath $Root $baseFile.path)) -ne $baseFile.sha256) { throw "Unsupported base game files: $($baseFile.path). Both PCs need the release's supported game version." }
    }
    $entries = @()
    $index = 0
    foreach ($file in $release.files) {
        $target = Get-SafePath $Root $file.path
        if ($file.mode -eq 'patch') {
            if ((Get-Sha $target) -ne $file.originalSha256) { throw "Original file differs: $($file.path). Installation stopped." }
        } elseif (Test-Path -LiteralPath $target) { throw "Would overwrite an existing file: $($file.path)" }
        $original = $null
        if ($file.mode -eq 'patch') { $original = $file.originalSha256 }
        $entries += [pscustomobject]@{path=$file.path; mode=$file.mode; originalSha256=$original; installedSha256=$file.installedSha256; backup=('backup/{0:D4}.bin' -f $index); attempted=$false}
        $index++
    }
    $state = [pscustomobject]@{schema=1; product=$script:Product; version=$release.version; root=$Root; releaseId=(Get-Sha (Join-Path $Bundle 'release.json')); phase='preparing'; files=$entries; requiredBase=$release.requiredBase}
    $null = New-Item -ItemType Directory -Path $stateRoot
    Write-Json (Join-Path $stateRoot 'state.json') $state
    try {
        $null = New-Item -ItemType Directory -Path (Join-Path $stateRoot 'backup')
        $null = New-Item -ItemType Directory -Path (Join-Path $stateRoot 'stage')
        for ($i = 0; $i -lt $entries.Count; $i++) {
            $entry = $entries[$i]
            $file = $release.files[$i]
            $stage = Get-SafePath $stateRoot ('stage/{0:D4}.bin' -f $i)
            $payload = Get-SafePath $Bundle $file.payload
            if ($entry.mode -eq 'patch') {
                $backup = Get-SafePath $stateRoot $entry.backup
                Copy-Item -LiteralPath (Get-SafePath $Root $entry.path) -Destination $backup
                if ((Get-Sha $backup) -ne $entry.originalSha256) { throw 'Backup verification failed.' }
                Apply-Delta $backup $payload $stage
            } else { Copy-Item -LiteralPath $payload -Destination $stage }
            if ((Get-Sha $stage) -ne $entry.installedSha256) { throw "Patched file failed verification: $($entry.path)" }
        }
        $state.phase = 'installing'
        Write-Json (Join-Path $stateRoot 'state.json') $state
        for ($i = 0; $i -lt $entries.Count; $i++) {
            $entry = $entries[$i]
            $target = Get-SafePath $Root $entry.path
            $parent = Split-Path -Parent $target
            if (-not (Test-Path -LiteralPath $parent)) { $null = New-Item -ItemType Directory -Path $parent -Force }
            # Journal intent before mutation, allowing interrupted installs to be recovered.
            $entry.attempted = $true
            Write-Json (Join-Path $stateRoot 'state.json') $state
            Copy-Item -LiteralPath (Get-SafePath $stateRoot ('stage/{0:D4}.bin' -f $i)) -Destination $target -Force
            if ((Get-Sha $target) -ne $entry.installedSha256) { throw 'Installed file failed verification.' }
        }
        $state.phase = 'installed'
        Write-Json (Join-Path $stateRoot 'state.json') $state
        Write-Host "Installed Endless Ascension $($release.version)."
        Write-Host "Release ID: $($state.releaseId)"
        Write-Host 'Run Check on BOTH PCs. Matching files do not by themselves prove multiplayer compatibility.'
    } catch {
        $failure = $_
        try { Remove-Installation $Root } catch { Write-Warning "Recovery requires Uninstall: $($_.Exception.Message)" }
        throw $failure
    }
}

function Test-Installation([string]$Bundle, [string]$Root) {
    $release = Read-Release $Bundle
    $state = Read-State $Root
    if ($null -eq $state -or $state.phase -ne 'installed') { throw 'No completed installation. Install or recover first.' }
    $releaseId = Get-Sha (Join-Path $Bundle 'release.json')
    if ($state.releaseId -ne $releaseId) { throw 'This folder contains a different release from the installed mod.' }
    foreach ($file in $release.files) {
        if ((Get-Sha (Get-SafePath $Root $file.path)) -ne $file.installedSha256) { throw "Installed mod file differs: $($file.path)" }
    }
    foreach ($baseFile in $release.requiredBase) {
        $overridden = @($release.files | Where-Object { $_.path.Replace('\','/') -eq $baseFile.path.Replace('\','/') })
        if ($overridden.Count -eq 0 -and (Get-Sha (Get-SafePath $Root $baseFile.path)) -ne $baseFile.sha256) { throw "Base file changed: $($baseFile.path)" }
    }
    Write-Host "Files verified: Endless Ascension $($release.version)"
    Write-Host "Release ID: $releaseId"
    Write-Host 'Both players must have this SAME full Release ID and a successful Check.'
    Write-Host 'This check covers release requirements and mod files; it is not an in-game co-op test.'
}
