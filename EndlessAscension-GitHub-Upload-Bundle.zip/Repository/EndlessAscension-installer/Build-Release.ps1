param(
    [Parameter(Mandatory=$true)][string]$CleanGamePath,
    [Parameter(Mandatory=$true)][string]$ModFilesPath,
    [Parameter(Mandatory=$true)][string]$PlanPath,
    [Parameter(Mandatory=$true)][string]$OutputPath,
    [Parameter(Mandatory=$true)][string]$Version
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Common.ps1')

if ($Version -notmatch '^[0-9]+\.[0-9]+\.[0-9]+(?:-[a-zA-Z0-9.-]+)?$') { throw 'Use a version such as 0.1.0-alpha.1.' }
$clean = Resolve-GameRoot $CleanGamePath
$modified = [IO.Path]::GetFullPath($ModFilesPath)
$destination = [IO.Path]::GetFullPath($OutputPath)
Assert-PlainPath $modified
Assert-PlainPath $destination
if (Test-Path -LiteralPath $destination) { throw 'OutputPath must be a new folder.' }
$plan = [IO.File]::ReadAllText((Get-SafePath (Split-Path ([IO.Path]::GetFullPath($PlanPath)) -Parent) (Split-Path $PlanPath -Leaf))) | ConvertFrom-Json
if (@($plan.files).Count -eq 0) { throw 'The build plan must include actual mod files.' }
if (Test-Path -LiteralPath (Join-Path $clean '.endless-ascension')) { throw 'CleanGamePath already has mod state. Use a clean reference copy.' }

# Emit only changed 4 KiB blocks for existing files. Original maps are not bundled wholesale.
if (-not ('EndlessAscension.DeltaBuilder' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Text;
namespace EndlessAscension {
    public static class DeltaBuilder {
        public static void Build(string original, string modified, string destination) {
            using (var source = File.OpenRead(original))
            using (var target = File.OpenRead(modified))
            using (var writer = new BinaryWriter(File.Create(destination))) {
                if (target.Length > 536870912) throw new InvalidDataException("File exceeds 512 MiB patch limit.");
                writer.Write(Encoding.ASCII.GetBytes("EAPATCH1"));
                writer.Write(target.Length);
                writer.Write(0);
                int count = 0;
                byte[] oldBytes = new byte[4096], newBytes = new byte[4096];
                long offset = 0;
                while (offset < target.Length) {
                    int needed = (int)Math.Min(4096, target.Length - offset);
                    int received = 0;
                    while (received < needed) {
                        int n = target.Read(newBytes, received, needed - received);
                        if (n == 0) throw new EndOfStreamException();
                        received += n;
                    }
                    int oldCount = 0;
                    while (oldCount < needed) {
                        int n = source.Read(oldBytes, oldCount, needed - oldCount);
                        if (n == 0) break;
                        oldCount += n;
                    }
                    bool differs = oldCount != needed;
                    for (int i = 0; !differs && i < needed; i++) differs = oldBytes[i] != newBytes[i];
                    if (differs) {
                        writer.Write(offset); writer.Write(needed); writer.Write(newBytes, 0, needed); count++;
                    }
                    offset += needed;
                }
                writer.BaseStream.Position = 16;
                writer.Write(count);
            }
        }
    }
}
'@
}

$seen = @{}
foreach ($file in $plan.files) {
    Assert-GameFile $file.path
    $key = $file.path.Replace('\','/').ToLowerInvariant()
    if ($seen.ContainsKey($key)) { throw 'Duplicate path in build plan.' }
    $seen[$key] = $true
    $source = Get-SafePath $modified $file.path
    $original = Get-SafePath $clean $file.path
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Missing mod file: $($file.path)" }
    if ($file.mode -eq 'patch') {
        if (-not (Test-Path -LiteralPath $original -PathType Leaf)) { throw "Missing original: $($file.path)" }
        if ((Get-Sha $source) -eq (Get-Sha $original)) { throw "Unchanged file in mod plan: $($file.path)" }
    } elseif ($file.mode -eq 'add') {
        if (Test-Path -LiteralPath $original) { throw "Added file exists in clean game: $($file.path)" }
    } else { throw 'Use mode patch or add.' }
}

$null = New-Item -ItemType Directory -Path $destination
$null = New-Item -ItemType Directory -Path (Join-Path $destination 'payload')
foreach ($name in @('Common.ps1','Install.ps1','Install.cmd','Uninstall.ps1','Uninstall.cmd','Check.ps1','Check.cmd','LEESMIJ.txt')) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination (Join-Path $destination $name)
}
$requirements = @('Binaries/Win32/SanctumGame-Win32-Shipping.exe','SanctumGame/CookedPC/SanctumGame.u','SanctumGame/CookedPC/Levels/Playable/RockyFields_04.sanctum')
if ($plan.PSObject.Properties['requiredBase']) { $requirements += @($plan.requiredBase) }
$requiredBase = @()
foreach ($relative in ($requirements | Select-Object -Unique)) {
    $requiredBase += [pscustomobject]@{path=$relative; sha256=(Get-Sha (Get-SafePath $clean $relative))}
}
$files = @()
$i = 0
foreach ($file in $plan.files) {
    $source = Get-SafePath $modified $file.path
    $original = Get-SafePath $clean $file.path
    $payloadRelative = 'payload/{0:D4}.bin' -f $i
    $payload = Get-SafePath $destination $payloadRelative
    $originalSha = $null
    if ($file.mode -eq 'patch') {
        $originalSha = Get-Sha $original
        [EndlessAscension.DeltaBuilder]::Build($original, $source, $payload)
    } else { Copy-Item -LiteralPath $source -Destination $payload }
    $files += [pscustomobject]@{path=$file.path; mode=$file.mode; originalSha256=$originalSha; installedSha256=(Get-Sha $source); payload=$payloadRelative; payloadSha256=(Get-Sha $payload)}
    $i++
}
$release = [pscustomobject]@{schema=1; product='EndlessAscension'; version=$Version; ready=$true; status='Packaged files; in-game multiplayer validation is a separate release requirement.'; requiredBase=$requiredBase; files=$files}
Write-Json (Join-Path $destination 'release.json') $release
$null = Read-Release $destination
Write-Host "Release folder built: $destination"
Write-Host 'Test installation, gameplay/co-op and uninstall before sharing. Packaging does not validate Unreal packages.'
