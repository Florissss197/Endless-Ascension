param([string]$GamePath)
$lock = $null
try {
    . (Join-Path $PSScriptRoot 'Common.ps1')
    $null = Read-Release $PSScriptRoot
    $root = Resolve-GameRoot $GamePath
    $lock = Enter-InstallLock $root
    Assert-GameClosed
    Install-Release $PSScriptRoot $root
    exit 0
} catch { Write-Host ('INSTALL STOPPED: ' + $_.Exception.Message) -ForegroundColor Red; exit 1 }
finally { if ($null -ne $lock) { $lock.ReleaseMutex(); $lock.Dispose() } }
