@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Check.ps1" %*
set "EA_RESULT=%ERRORLEVEL%"
echo.
pause
exit /b %EA_RESULT%
