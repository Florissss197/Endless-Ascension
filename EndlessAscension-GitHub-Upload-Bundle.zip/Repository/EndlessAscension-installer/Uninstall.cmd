@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Uninstall.ps1" %*
set "EA_RESULT=%ERRORLEVEL%"
echo.
pause
exit /b %EA_RESULT%
