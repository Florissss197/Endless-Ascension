param([string]$GamePath)
$lock = $null
try {
    . (Join-Path $PSScriptRoot 'Common.ps1')
    $root = Resolve-GameRoot $GamePath
    $lock = Enter-InstallLock $root
    Assert-GameClosed
    Remove-Installation $root
    exit 0
} catch { Write-Host ('UNINSTALL STOPPED: ' + $_.Exception.Message) -ForegroundColor Red; exit 1 }
finally { if ($null -ne $lock) { $lock.ReleaseMutex(); $lock.Dispose() } }
